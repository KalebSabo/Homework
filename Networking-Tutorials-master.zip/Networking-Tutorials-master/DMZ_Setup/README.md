# DMZ Setup
![alt text](https://github.com/ngimb64/Networking-Tutorials/blob/master/DMZ_Setup/DMZSetup.png?raw=true)

## Prereqs
Cisco Packet Tracer (7.3.0)

## Installation
After downloading Packet Tracer simply double
click the EXE and run default installation.

## Purpose
This lab covers DMZ netork architecture & other handy network security controls.
Tutorial can be found at https://cybr.com/it-ops-archives/project-dmz-and-network-hardening-tutorial-with-packet-tracer/