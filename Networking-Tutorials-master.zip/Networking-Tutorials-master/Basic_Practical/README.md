# Basic Practical
![alt text](https://github.com/ngimb64/Networking-Tutorials/blob/master/Basic_Practical/BasicPractical.png?raw=true)

## Prereqs
> Cisco Packet Tracer (7.3.0)

## Installation
> After downloading Packet Tracer simply double
> click the EXE and run default installation.

## Purpose
> This lab is geared towards people who are relatively
> new to networking and trying to move from beginner
> to a more intermediate level.